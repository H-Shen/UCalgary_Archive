package ca.ucalgary.seng300.dao;

import ca.ucalgary.seng300.pojo.Client;

import java.util.List;

public interface ClientMapper {

    // query
    List<Client> getClientList();
    Client getClientById(String id);
    Client getClientByName(String name);
    Client getClientByPhoneNumber(String phoneNumber);
    Client getClientByAddress(String address);
    Client getClientByEmailAddress(String emailAddress);
    // insert
    // update
    // delete
}
