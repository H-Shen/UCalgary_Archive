package ca.ucalgary.seng300.pojo;

import org.apache.ibatis.type.Alias;

@Alias("Room")
public class Room {

    private int number;
    private String type;
    private double price;
    private boolean isEmpty;

    public Room(int number, String type, double price, boolean isEmpty) {
        this.number = number;
        this.type = type;
        this.price = price;
        this.isEmpty = isEmpty;
    }

    @Override
    public String toString() {
        return "Room{" +
                "number=" + number +
                ", type='" + type + '\'' +
                ", price=" + price +
                ", isEmpty=" + isEmpty +
                '}';
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean isEmpty() {
        return isEmpty;
    }

    public void setEmpty(boolean empty) {
        isEmpty = empty;
    }
}
