package ca.ucalgary.seng300.dao;

import ca.ucalgary.seng300.pojo.Room;


import java.util.List;

public interface RoomMapper {
    //query
    List<Room> getRoomList();


}
