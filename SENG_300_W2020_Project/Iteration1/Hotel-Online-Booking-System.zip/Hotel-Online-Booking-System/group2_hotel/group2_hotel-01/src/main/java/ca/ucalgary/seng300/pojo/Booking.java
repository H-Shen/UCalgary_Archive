package ca.ucalgary.seng300.pojo;

import org.apache.ibatis.type.Alias;

import java.sql.Timestamp;

@Alias("Booking")
public class Booking {

    private String bookingId;
    private int    roomNumber;
    private Timestamp bookingDate;
    private Timestamp checkinDate;
    private Timestamp checkoutDate;
    private String phoneNumber;

    public Booking(String bookingId, int roomNumber, Timestamp bookingDate, Timestamp checkinDate, Timestamp checkoutDate, String phoneNumber) {
        this.bookingId = bookingId;
        this.roomNumber = roomNumber;
        this.bookingDate = bookingDate;
        this.checkinDate = checkinDate;
        this.checkoutDate = checkoutDate;
        this.phoneNumber = phoneNumber;
    }

    @Override
    public String toString() {
        return "Booking{" +
                "bookingId=" + bookingId +
                ", roomNumber=" + roomNumber +
                ", bookingDate=" + bookingDate +
                ", checkinDate=" + checkinDate +
                ", checkoutDate=" + checkoutDate +
                ", phoneNumber='" + phoneNumber + '\'' +
                '}';
    }

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public Timestamp getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Timestamp bookingDate) {
        this.bookingDate = bookingDate;
    }

    public Timestamp getCheckinDate() {
        return checkinDate;
    }

    public void setCheckinDate(Timestamp checkinDate) {
        this.checkinDate = checkinDate;
    }

    public Timestamp getCheckoutDate() {
        return checkoutDate;
    }

    public void setCheckoutDate(Timestamp checkoutDate) {
        this.checkoutDate = checkoutDate;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
