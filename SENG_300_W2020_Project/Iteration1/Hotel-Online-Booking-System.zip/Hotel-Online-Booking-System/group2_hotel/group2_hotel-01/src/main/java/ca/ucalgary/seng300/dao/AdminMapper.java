package ca.ucalgary.seng300.dao;

public interface AdminMapper {
}
