package ca.ucalgary.seng300.pojo;

import org.apache.ibatis.type.Alias;

import java.sql.Timestamp;

@Alias("Checkin")
public class Checkin {
    private String checkinId;
    private int    roomNumber;
    private String clientId;
    private Timestamp checkinDate;
    private Timestamp checkoutDate;

    public Checkin(String checkinId, int roomNumber, String clientId, Timestamp checkinDate, Timestamp checkoutDate) {
        this.checkinId = checkinId;
        this.roomNumber = roomNumber;
        this.clientId = clientId;
        this.checkinDate = checkinDate;
        this.checkoutDate = checkoutDate;
    }

    @Override
    public String toString() {
        return "Checkin{" +
                "checkinId=" + checkinId +
                ", roomNumber=" + roomNumber +
                ", clientId='" + clientId + '\'' +
                ", checkinDate=" + checkinDate +
                ", checkoutDate=" + checkoutDate +
                '}';
    }

    public String getCheckinId() {
        return checkinId;
    }

    public void setCheckinId(String checkinId) {
        this.checkinId = checkinId;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public Timestamp getCheckinDate() {
        return checkinDate;
    }

    public void setCheckinDate(Timestamp checkinDate) {
        this.checkinDate = checkinDate;
    }

    public Timestamp getCheckoutDate() {
        return checkoutDate;
    }

    public void setCheckoutDate(Timestamp checkoutDate) {
        this.checkoutDate = checkoutDate;
    }
}
