package ca.ucalgary.seng300.dao;

import ca.ucalgary.seng300.pojo.Room;
import ca.ucalgary.seng300.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import java.util.List;

public class RoomMapperTest {
    @Test
    public void testGetAllRooms() {
        try (SqlSession sqlSession = MybatisUtils.getSqlSession()) {
            RoomMapper roomMapper = sqlSession.getMapper(RoomMapper.class);
            List<Room> roomList   = roomMapper.getRoomList();
            for (Room room : roomList) {
                System.out.println(room);
            }
        }
    }
}
