package ca.ucalgary.seng300.dao;

public class CheckinMapperTest {
}
