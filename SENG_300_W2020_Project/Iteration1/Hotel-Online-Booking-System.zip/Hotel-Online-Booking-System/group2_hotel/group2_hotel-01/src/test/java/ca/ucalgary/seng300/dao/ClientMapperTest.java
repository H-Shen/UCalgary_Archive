package ca.ucalgary.seng300.dao;

import ca.ucalgary.seng300.pojo.Client;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import ca.ucalgary.seng300.utils.MybatisUtils;

import java.util.List;

public class ClientMapperTest {

    @Test
    public void testGetAllClients() {
        try (SqlSession sqlSession = MybatisUtils.getSqlSession()) {
            ClientMapper clientMapper = sqlSession.getMapper(ClientMapper.class);
            List<Client> clientList = clientMapper.getClientList();
            for (Client client : clientList) {
                System.out.println(client);
            }
        }
    }
    @Test
    public void testGetClientById() {
        try (SqlSession sqlSession = MybatisUtils.getSqlSession()) {
            ClientMapper clientMapper = sqlSession.getMapper(ClientMapper.class);
            Client client = clientMapper.getClientById("170658971466876");
            System.out.println(client);
        }
    }
    @Test
    public void testGetClientByName() {
        try (SqlSession sqlSession = MybatisUtils.getSqlSession()) {
            ClientMapper clientMapper = sqlSession.getMapper(ClientMapper.class);
            Client client = clientMapper.getClientByName("Carrie Payne");
            System.out.println(client);
        }
    }
    @Test
    public void testGetClientByPhoneNumber() {
        try (SqlSession sqlSession = MybatisUtils.getSqlSession()) {
            ClientMapper clientMapper = sqlSession.getMapper(ClientMapper.class);
            Client client = clientMapper.getClientByPhoneNumber("1-810-793-0129");
            System.out.println(client);
        }
    }
    @Test
    public void testGetClientByAddress() {
        try (SqlSession sqlSession = MybatisUtils.getSqlSession()) {
            ClientMapper clientMapper = sqlSession.getMapper(ClientMapper.class);
            Client client = clientMapper.getClientByAddress("9420 Tyler Tunnel\n" +
                    "Lake Emily, AK 66272");
            System.out.println(client);
        }
    }
    @Test
    public void testGetClientByEmailAddress() {
        try (SqlSession sqlSession = MybatisUtils.getSqlSession()) {
            ClientMapper clientMapper = sqlSession.getMapper(ClientMapper.class);
            Client client = clientMapper.getClientByEmailAddress("brandoncharles@gmail.com");
            System.out.println(client);
        }
    }
}
