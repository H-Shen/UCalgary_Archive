/**
 * SENG 513
 * Assignment 2: Minesweeper
 * UCID: 30063099
 *
 * Notice before grading: some code/logic are referred
 * from https://repl.it/@pfederl/Minesweeper-Game-Engine
 */

// All constants are defined here
const STATE_HIDDEN = "hidden";
const STATE_SHOWN = "shown";
const STATE_MARKED = "marked";
const DIGIT_TO_COLOR = {
    "0": "",
    "1": "<span style='color:#001ff2'>" + "1" + "</span>",
    "2": "<span style='color:#377c21'>" + "2" + "</span>",
    "3": "<span style='color:#e93223'>" + "3" + "</span>",
    "4": "<span style='color:#202bae'>" + "4" + "</span>",
    "5": "<span style='color:#77150e'>" + "5" + "</span>",
    "6": "<span style='color:#377e80'>" + "6" + "</span>",
    "7": "<span style='color:#000000'>" + "7" + "</span>",
    "8": "<span style='color:#808080'>" + "8" + "</span>",
}
const TIMEOUT = 1000;
const STEPS = 8;
const DX = [-1, 1, 0, 0, -1, 1, -1, 1];
const DY = [0, 0, -1, 1, -1, 1, 1, -1];

const ROWS_EASY = 9;
const ROWS_MEDIUM = 16;
const ROWS_HARD = 16;

const COLS_EASY = 9;
const COLS_MEDIUM = 16;
const COLS_HARD = 21;

const MINES_EASY = 10;
const MINES_MEDIUM = 40;
const MINES_HARD = 99;

const HIT_A_BOMB = "#ff0000";
const HIDDEN_BLOCK = "#bcbcbc";
const COVERED_BLOCK = "white";

// All members are defined here
let gameDifficulty = "";
let nrows = 0;
let ncols = 0;
let nmines = 0;
let nmarked = 0;
let nuncovered = 0;
let exploded = false;
let arr = [];
let board = [];
let gameActive;

let time = document.getElementById("timer");
let myTimer = setInterval(function () {
    ++time.innerHTML;
}, TIMEOUT)

// Initialize the game
function init(nrows_, ncols_, nmines_) {
    nrows = nrows_;
    ncols = ncols_;
    nmines = nmines_;
    nmarked = 0;
    nuncovered = 0;
    exploded = false;

    arr = array2d(
        nrows, ncols,
        () => ({ mine: false, state: STATE_HIDDEN, count: 0 }));
    writeEmptyBoardToDocument();
    board = this.getBoardFromDocument();
    for (let i = 0; i < nrows; ++i) {
        for (let j = 0; j < ncols; ++j) {
            board[i][j].style.backgroundColor = "#bcbcbc"
        }
    }

    gameActive = true;
    document.getElementById("remain").innerText = (nmines - nmarked).toString();
    // clear timer
    clearInterval(myTimer);
    time.innerText = "0";
    // restart timing
    myTimer = setInterval(function () {
        ++time.innerHTML;
    }, TIMEOUT)
}

// Set the game level
function setGameLevel(gameLevel = "Easy") {
    gameDifficulty = gameLevel;
    if (gameLevel === "Easy") {
        init(ROWS_EASY, COLS_EASY, MINES_EASY);
    } else if (gameLevel === "Medium") {
        init(ROWS_MEDIUM, COLS_MEDIUM, MINES_MEDIUM);
    } else {
        init(ROWS_HARD, COLS_HARD, MINES_HARD);
    }
    // Re-binding every time when the game level is set
    // Here I use Jquery Mobile 'taphold' binding instead of setting a timer
    $(function () {
        $("span.block").bind("taphold", function () {
            if (gameActive && mark($(this).data().i, $(this).data().j)) {
                document.getElementById("remain").innerText = (nmines - nmarked).toString();
                outputToDocument();
                outputToConsole();
                printCurrentStatusToConsole();
                console.log("Long tap detected!");
            }
        });
    });
}

// Set the size of the board according to the game-difficulty given, by changing inline css
// directly
function setBoardSize(gameLevel) {
    if (gameLevel === "Easy") {
        document.getElementById("inline_css").innerText =
            "        .block {\n" +
            "            width: 70px;\n" +
            "            height: 70px;\n" +
            "            line-height: 70px;\n" +
            "            display: block;\n" +
            "            text-align: center;\n" +
            "            border: solid 1px #000000;\n" +
            "            user-select: none;\n" +
            "            cursor: pointer;\n" +
            "        }\n" +
            "\n" +
            "        .block:hover {\n" +
            "            background: #aee5f1;\n" +
            "        }";
    } else if (gameLevel === "Medium") {
        document.getElementById("inline_css").innerText =
            "        .block {\n" +
            "            width: 40px;\n" +
            "            height: 40px;\n" +
            "            line-height: 40px;\n" +
            "            display: block;\n" +
            "            text-align: center;\n" +
            "            border: solid 1px #000000;\n" +
            "            user-select: none;\n" +
            "            cursor: pointer;\n" +
            "        }\n" +
            "\n" +
            "        .block:hover {\n" +
            "            background: #aee5f1;\n" +
            "        }";
    } else {
        document.getElementById("inline_css").innerText =
            "        .block {\n" +
            "            width: 30px;\n" +
            "            height: 30px;\n" +
            "            line-height: 30px;\n" +
            "            display: block;\n" +
            "            text-align: center;\n" +
            "            border: solid 1px #000000;\n" +
            "            user-select: none;\n" +
            "            cursor: pointer;\n" +
            "        }\n" +
            "\n" +
            "        .block:hover {\n" +
            "            background: #aee5f1;\n" +
            "        }";
    }
}

// Reset
function reset() {
    nrows = 0;
    ncols = 0;
    nmines = 0;
    nmarked = 0;
    nuncovered = 0;
    exploded = 0;
    arr = [];
    board = [];
}

// Generate
function array2d(nrows, ncols, val) {
    const res = [];
    for (let row = 0; row < nrows; ++row) {
        res[row] = [];
        for (let col = 0; col < ncols; ++col)
            res[row][col] = val(row, col);
    }
    return res;
}

// returns random integer in range [min, max]
function rndInt(min, max) {
    [min, max] = [Math.ceil(min), Math.floor(max)]
    return min + Math.floor(Math.random() * (max - min + 1));
}

function blockClick(row, col, event) {
    // Skip if the game is not active anymore
    if (!gameActive) {
        return;
    }
    // Skip all shown blocks
    if (arr[row][col].state === STATE_SHOWN) {
        return;
    }
    // Case 1: if the user left-clicks the mouse on the block
    if (event.button === 0) {
        if (uncover(row, col)) {
            let result = outputToDocument();
            if (result === 1) {
                alert("Game Over! You explode a mine!");
                gameActive = false;
                // stop timing
                clearInterval(myTimer);
            } else if (result === 2) {
                alert("Map clear! You win the game!");
                // set the number of remaining mines to 0
                document.getElementById("remain").innerText = "0";
                // flags all hidden marks and output again
                for (let i = 0; i < nrows; ++i) {
                    for (let j = 0; j < ncols; ++j) {
                        if (arr[i][j].state === STATE_HIDDEN) {
                            arr[i][j].state = STATE_MARKED;
                        }
                    }
                }
                outputToDocument();
                gameActive = false;
                // stop timing
                clearInterval(myTimer);
            }
            outputToConsole();
            printCurrentStatusToConsole();
        }
    }
    // Case 2: if the user right-clicks the mouse on the block
    else if (event.button === 2) {
        if (mark(row, col)) {
            document.getElementById("remain").innerText = (nmines - nmarked).toString();
            outputToDocument();
            outputToConsole();
            printCurrentStatusToConsole();
        }
    }
}

// Check if the location is inside the board
function validCoord(row, col) {
    return row >= 0 && row < nrows && col >= 0 && col < ncols;
}

// Count the mines surrounding (row, col)
function count(row, col) {
    const c = (r, c) =>
        (validCoord(r, c) && arr[r][c].mine ? 1 : 0);
    let res = 0;
    for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
            res += c(row + dr, col + dc);
        }
    }
    return res;
}

// Implement the user's first uncover
function sprinkleMines(row, col) {
    // prepare a list of allowed coordinates for mine placement
    let allowed = [];
    for (let r = 0; r < nrows; r++) {
        for (let c = 0; c < ncols; c++) {
            if (Math.abs(row - r) > 2 || Math.abs(col - c) > 2) {
                allowed.push([r, c]);
            }
        }
    }
    nmines = Math.min(nmines, allowed.length);
    for (let i = 0; i < nmines; i++) {
        let j = rndInt(i, allowed.length - 1);
        [allowed[i], allowed[j]] = [allowed[j], allowed[i]];
        let [r, c] = allowed[i];
        arr[r][c].mine = true;
    }
    // erase any marks (in case user placed them) and update counts
    for (let r = 0; r < nrows; r++) {
        for (let c = 0; c < ncols; c++) {
            if (arr[r][c].state === STATE_MARKED)
                arr[r][c].state = STATE_HIDDEN;
            arr[r][c].count = count(r, c);
        }
    }
    // print the map of mines and the map of counts after sprinkling
    // for the purpose of debugging
    let mines = [];
    for (let row = 0; row < nrows; row++) {
        let s = "";
        for (let col = 0; col < ncols; col++) {
            s += arr[row][col].mine ? "B" : ".";
        }
        s += "  |  ";
        for (let col = 0; col < ncols; col++) {
            s += arr[row][col].count.toString();
        }
        mines[row] = s;
    }
    console.log("Mines and counts after sprinkling:");
    console.log(mines.join("\n"), "\n");
}

// uncovers a cell at a given coordinate
// this is the 'left-click' functionality
function uncover(row, col) {
    console.log("uncover", row, col);
    // if coordinates invalid, refuse this request
    if (!validCoord(row, col)) {
        return false;
    }
    // if this is the very first move, populate the mines, but make
    // sure the current cell does not get a mine
    if (nuncovered === 0) {
        sprinkleMines(row, col);
    }
    // if cell is not hidden, ignore this move
    if (arr[row][col].state !== STATE_HIDDEN) {
        return false;
    }
    // floodfill all 0-count cells by depth-first search
    const dfs = (r, c) => {
        // Base case 1:
        if (!validCoord(r, c)) {
            return;
        }
        // Base case 2:
        if (arr[r][c].state !== STATE_HIDDEN) {
            return;
        }
        arr[r][c].state = STATE_SHOWN;
        nuncovered++;
        // Base case 3: there is at least 1 mine which is around (r, c)
        if (arr[r][c].count !== 0) {
            return;
        }
        // Recursively dfs on 8 directions
        for (let step = 0; step < STEPS; ++step) {
            dfs(r + DX[step], c + DY[step]);
        }
    };
    dfs(row, col);
    // have we hit a mine?
    if (arr[row][col].mine) {
        board[row][col].style.backgroundColor = HIT_A_BOMB;
        exploded = true;
    }
    return true;
}

// puts a flag on a cell
// this is the 'right-click' or 'long-tap' functionality
// return false if any invalid move is performed, otherwise return true
function mark(row, col) {
    console.log("mark", row, col);
    // if coordinates invalid, refuse this request
    if (!validCoord(row, col)) {
        return false;
    }
    // if cell already uncovered, refuse this
    console.log("marking previous state=", arr[row][col].state);
    if (arr[row][col].state === STATE_SHOWN) {
        return false;
    }
    // accept the move and flip the marked status and update 'nmarked'
    if (arr[row][col].state === STATE_MARKED) {
        --nmarked;
        arr[row][col].state = STATE_HIDDEN;
    } else {
        ++nmarked;
        arr[row][col].state = STATE_MARKED;
    }
    return true;
}

// returns array of strings representing the rendering of the board
//      "H" = hidden cell - no bomb
//      "F" = hidden cell with a mark / flag
//      "M" = uncovered mine (game should be over now)
// '0'..'9' = number of mines in adjacent cells
function outputToConsole() {
    const res = [];
    for (let row = 0; row < nrows; row++) {
        let s = "";
        for (let col = 0; col < ncols; col++) {
            let a = arr[row][col];
            if (exploded && a.mine) {
                s += "M";
            } else if (a.state === STATE_HIDDEN) {
                s += "H";
            } else if (a.state === STATE_MARKED) {
                s += "F";
            } else if (a.mine) {
                s += "M";
            } else {
                s += a.count.toString();
            }
        }
        res[row] = s;
    }
    return res;
}

function outputToDocument() {
    let status = 0; // 0: in progress, 1: touch a mine, 2: clear the map
    for (let row = 0; row < nrows; row++) {
        for (let col = 0; col < ncols; col++) {
            let a = arr[row][col];
            if (exploded && a.mine) {
                board[row][col].innerHTML = '<img src=\"bomb.png\" style=\"height:80%;\" alt=\"bomb.png\">';
                status = 1;
            } else if (a.state === STATE_HIDDEN) {
                board[row][col].style.backgroundColor = HIDDEN_BLOCK;
                board[row][col].innerHTML = "";
            } else if (a.state === STATE_MARKED) {
                board[row][col].innerHTML = '<img src=\"flag.png\" style=\"height:100%;\" alt=\"flag.png\">';
            } else if (a.mine) {
                board[row][col].innerHTML = '<img src=\"bomb.png\" style=\"height:80%;\" alt=\"bomb.png\">';
                status = 1;
            } else {
                board[row][col].style.backgroundColor = COVERED_BLOCK;
                board[row][col].innerHTML = DIGIT_TO_COLOR[a.count.toString()];
            }
        }
    }
    if (status === 0 && nuncovered === nrows * ncols - nmines) {
        status = 2;
    }
    return status;
}

function writeEmptyBoardToDocument() {
    let board = "";
    for (let i = 0; i < nrows; ++i) {
        board += "<tr>";
        for (let j = 0; j < ncols; ++j) {
            board += '<td><span class="block" data-i=' + i + ' data-j=' + j + ' onmousedown="blockClick(' + i + ',' + j + ',event)"></span></td>';
        }
        board += "<tr>";
    }
    document.getElementById("board").innerHTML = board;
}

function getBoardFromDocument() {
    let getBlocks = document.getElementsByClassName("block");
    let board = new Array(nrows);
    for (let i = 0; i < nrows; ++i) {
        board[i] = new Array(ncols);
    }
    let index = 0;
    for (let i = 0; i < nrows; ++i) {
        for (let j = 0; j < ncols; ++j) {
            board[i][j] = getBlocks[index];
            ++index;
        }
    }
    return board;
}

// Print the status of the board to console
function printCurrentStatusToConsole() {
    let done = exploded ||
        nuncovered === nrows * ncols - nmines;
    return {
        done: done,
        exploded: exploded,
        nrows: nrows,
        ncols: ncols,
        nmarked: nmarked,
        nuncovered: nuncovered,
        nmines: nmines
    }
}

// Binding the button
$(function () {
    $("#button1").click(function () {
        reset();
        setBoardSize("Easy");
        setGameLevel("Easy");
        $("#button1").css("background", "green");
        $("#button2").css("background", "black");
        $("#button3").css("background", "black");
    });
    $("#button2").click(function () {
        reset();
        setBoardSize("Medium");
        setGameLevel("Medium");
        $("#button1").css("background", "black");
        $("#button2").css("background", "green");
        $("#button3").css("background", "black");
    });
    $("#button3").click(function () {
        reset();
        setBoardSize("Hard");
        setGameLevel("Hard");
        $("#button1").css("background", "black");
        $("#button2").css("background", "black");
        $("#button3").css("background", "green");
    });
    $("#button4").click(function () {
        reset();
        setGameLevel(gameDifficulty);
    });
});

// Get rid of loading message
$.mobile.loading().hide();

// Set the default game difficulty as 'Medium'
setBoardSize("Medium");
setGameLevel("Medium");
$("#button2").css("background", "green");

// Set the default status
document.getElementById("remain").innerText = (nmines - nmarked).toString();